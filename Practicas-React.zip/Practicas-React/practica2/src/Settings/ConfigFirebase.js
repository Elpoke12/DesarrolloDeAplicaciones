  
import firebase from 'firebase/app';
import 'firebase/database';

const config={
    apiKey: "AIzaSyCe7opm6T7pPjCNmAhGLX8zCCMFhftNutc",
    authDomain: "peliculasdb-97b06.firebaseapp.com",
    databaseURL: "https://peliculasdb-97b06.firebaseio.com",
    projectId: "peliculasdb-97b06",
    storageBucket: "peliculasdb-97b06.appspot.com",
    messagingSenderId: "284372757715",
    appId: "1:284372757715:web:f7bc0b0b6f56bdb8c2f826",
    measurementId: "G-5RDQ0GW3V7"

}

const fb = !firebase.apps.lenght ? firebase.initializeApp(config):firebase.app()

export default fb;