import '../App.css';

const Formulario = (props) => {
    return ( 
        <div className="Form">
        <form onSubmit={props.enviar}>
        <div>
          <label htmlFor="id">id</label>
          <input
            type="text"
            placeholder="Fecha de Estreno"
            onChange={props.guardarCambios}
            value={props.pelicula.id}
            name="id"
            disabled={props.desactivado}
          />
        </div>
        <div>
          <label htmlFor="nombre">Nombre</label>
          <input
            type="text"
            placeholder="Ejm. Juan Perez"
            onChange={props.guardarCambios}
            value={props.pelicula.nombre}
            name="nombre"
          />
        </div>
        <div>
          <label htmlFor="director">Director</label>
          <input
            type="email"
            placeholder="Ej. Director@Director.com"
            onChange={props.guardarCambios}
            value={props.pelicula.Director}
            name="Director"
          />
        </div>
        <div>
          <label htmlFor="Genero">Genero</label>
          <select name="Genero" value={props.pelicula.Genero} onChange={props.guardarCambios}>
            <option value="selecciona">selecciona</option>
            <option value="Accion">Accion</option>
            <option value="Drama">Drama</option>
            <option value="Terror">Terror</option>
          </select>
        </div>
        <button>Enviar</button>
        </form>
      </div>
    );
}
 
export default Formulario;