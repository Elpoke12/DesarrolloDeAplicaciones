import '../App.css';
import { Button, Table } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const Listado = (props) => {
    return ( 
        <div className="List">
        {
                    
            props.lista.length===0   
            ? <p>No hay Peliculas:(</p>
            : 
        
             <Table striped bordered hover>
            <thead>
              <tr>
                <th>Matricula</th>
                <th>Nombre</th>
                <th>Director</th>
                <th>Genero</th>
                <th></th>
                <th></th> 
              </tr>
            </thead>
              <tbody>
            {
              props.lista.map((a,index)=>
                <tr key={index}>
                    <td>{a.id}</td>
                    <td>{a.nombre}</td>
                    <td>{a.Director}</td>
                    <td>{a.Genero}</td>
                    <td><Button onClick={()=>props.eliminar(a.matricula)} variant="danger">Eliminar</Button></td>
                    <td><Button onClick={()=>props.modificar(a.matricula)}variant="success">Modificar</Button></td>
                </tr>
              )
            }
              </tbody>
            </Table>
          }

          </div>
     );
}
 
export default Listado;