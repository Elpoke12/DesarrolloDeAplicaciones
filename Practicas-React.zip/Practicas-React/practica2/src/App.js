import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react';
import Swal from 'sweetalert2';
import Header from 'src/Components/Header.js';
import Formulario from 'src/Components/Formulario.js';
import Listado from 'src/Components/Listado.js';
import "bootstrap/dist/css/bootstrap.min.css";
import firebase from "src/Settings/ConfigFirebase.js";

class App extends Component {
  constructor() {
    super();
    this.state = {
      pelicula:{
        id:"",
        nombre:"",
        Director:"",
        genero:""
      },
      lista:[],
      desactivado:false,
    };
  }
  
  componentDidMount(){
    firebase.database().ref('peliculas').on('value', snapshot=> {
      let peliculasLista=[];
      snapshot.forEach(row=>{
          peliculasLista.push({
            id:row.key,
            nombre:row.val().nombre,
            Director:row.val().Director,
            genero:row.val().genero
          })
      })
      this.setState({
        ...this.state,
        lista:peliculasLista
      })
    });
  }


  guardarCambios=(e)=>{
    this.setState({ 
      ...this.state,
      pelicula:{
      ...this.state.pelicula,  
      [e.target.name]: e.target.value
      } 
       
    });
  }
  
  eliminar=(id)=>{

    firebase.database().ref('peliculas/' + id).set(null).then(() => {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Eliminado',
        showConfirmButton: false,
        timer: 1500
      })
    });

    const temporal = this.state.lista.filter(a=>a.id!==id)
    this.setState({
      ...this.state,
      lista:temporal
    })
  }

  modificar=(id)=>{
    const temporal = this.state.lista.find(a=>a.id===id);
    this.setState({
      ...this.state,
      pelicula:{
        id:temporal.id,
        nombre:temporal.nombre,
        Director:temporal.Director,
        genero:temporal.genero
      },
      desactivado:true
    })
  }
  enviar=(e)=>{
    e.preventDefault();

    const {id,nombre, Director, genero} = this.state.pelicula;
      
    const vacios = (id.length===0 && nombre.length===0 && Director.length===0 && genero.length===0) || genero==="selecciona" 

    if(!vacios){

      firebase.database().ref('peliculas/' + id).update(this.state.pelicula).then(() => {
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'pelicula agregada',
          showConfirmButton: false,
          timer: 1500
        })
      });


      
      
      let temporal = this.state.lista;

      if(this.state.desactivado===true){
        temporal= temporal.filter(a=>a.id!==id)
      }

      this.setState({
        ...this.state,
        lista:[...temporal,this.state.pelicula],
        pelicula:{
          id:"",
          nombre:"",
          Director:"",
          genero:""
        },
        desactivado:false
      })
    }
    else{
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Llena todos los campos',
        showConfirmButton: false,
        timer: 1500
      })
      return;
    }
    
  }
  
  render() {
    
    return (
      <div className="App">
        <Header/>
        <div className="Containers">
          <Formulario
              enviar={this.enviar}
              guardarCambios={this.guardarCambios}
              pelicula={this.state.pelicula}
              desactivado={this.state.desactivado}
          />
          <Listado
            lista={this.state.lista}
            eliminar={this.eliminar}
            modificar={this.modificar}
          />
          
        </div>
      </div>
    )
  }
}
export default App;
